
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import com.bazaarvoice.jolt.Chainr;
import com.bazaarvoice.jolt.JsonUtils;

public class App {
	public static void main(String[] args) {
		Object specJSON = null;
		try {
			InputStream is = new FileInputStream("src\\main\\resources\\spec.json");
			specJSON = JsonUtils.jsonToObject(is);
			Chainr chainr = Chainr.fromSpec(specJSON);
			Object inputJSON = JsonUtils.jsonToObject(new String(Files.readAllBytes(Paths.get("src\\main\\resources\\input.json"))));
			Object transformedOutput = chainr.transform(inputJSON);
			System.out.println("**********************output **********************");
			System.out.println(JsonUtils.toJsonString(transformedOutput));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}